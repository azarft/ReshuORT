package com.alatoo.reshu_ort.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER
}
