package com.alatoo.reshu_ort;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReshuOrtApplicationTests {

	@Test
	void contextLoads() {
	}

}
